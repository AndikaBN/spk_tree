import pandas as pd
from pathlib import Path

# Baca dataset existing
excel_path = Path('media/dataset.xlsx')
df = pd.read_excel(excel_path, sheet_name=0)

print("Dataset sebelum diperbaiki:")
print("Jurusan counts:", df['JURUSAN'].value_counts())
print("Minat counts:")
print(df['Unnamed: 6'].value_counts())

minat_akuntansi = ['Berhitung', 'Analisis Data', 'Keuangan']

df_fixed = df.copy()

indices_to_change = []

for idx, row in df_fixed.iterrows():
    if pd.notna(row['Unnamed: 6']) and row['Unnamed: 6'] != 'MINAT':
        nilai_mtk = row['NILAI KRITERIA']
        if pd.notna(nilai_mtk) and isinstance(nilai_mtk, (int, float)) and nilai_mtk >= 80:
            if len(indices_to_change) < 20:  
                indices_to_change.append(idx)

for idx in indices_to_change[:20]:
    df_fixed.at[idx, 'JURUSAN'] = 'AKUNTANSI'

print(f"\nMengubah {len(indices_to_change[:20])} data menjadi AKUNTANSI")
print("Dataset setelah diperbaiki:")
print("Jurusan counts:", df_fixed['JURUSAN'].value_counts())

with pd.ExcelWriter('media/dataset.xlsx', engine='openpyxl') as writer:
    df_fixed.to_excel(writer, sheet_name='Sheet1', index=False)
    
    try:
        df2 = pd.read_excel(excel_path, sheet_name=1)
        df2_fixed = df2.copy()
        if 'JURUSAN' in df2_fixed.columns:
            indices_to_change_2 = []
            for idx, row in df2_fixed.iterrows():
                if pd.notna(row.get('Unnamed: 6', '')) and row.get('Unnamed: 6', '') != 'MINAT':
                    nilai_mtk = row.get('NILAI KRITERIA', 0)
                    if pd.notna(nilai_mtk) and isinstance(nilai_mtk, (int, float)) and nilai_mtk >= 80:
                        if len(indices_to_change_2) < 15:
                            indices_to_change_2.append(idx)
            
            for idx in indices_to_change_2:
                df2_fixed.at[idx, 'JURUSAN'] = 'AKUNTANSI'
                
        df2_fixed.to_excel(writer, sheet_name='Sheet4', index=False)
        print(f"Sheet 2 juga diupdate dengan {len(indices_to_change_2)} data AKUNTANSI")
    except:
        print("Sheet kedua tidak ada atau error")

print("\nDataset berhasil diupdate! Sekarang akan ada entropy yang bervariasi.")
