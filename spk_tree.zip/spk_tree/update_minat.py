import pandas as pd
from pathlib import Path

# Baca dataset
excel_path = Path('media/dataset.xlsx')
df = pd.read_excel(excel_path, sheet_name=0)

print("Current minat values:")
print(df['Unnamed: 6'].value_counts())

# Map old values to new minat choices
minat_mapping = {
    'Komunikasi': 'Komunikasi',      # sudah ada
    'Administrasi': 'Administrasi',  # sudah ada  
    'Korespodensi': 'Korespodensi',  # sudah ada
    'MINAT': 'Administrasi'          # header row, ganti jadi default
}

# Update minat values and add new ones
df_updated = df.copy()

# Update existing values
for old_val, new_val in minat_mapping.items():
    mask = df_updated['Unnamed: 6'] == old_val
    df_updated.loc[mask, 'Unnamed: 6'] = new_val

# Tambahkan beberapa data dengan minat baru
# Ganti beberapa yang AKUNTANSI dengan minat "Berhitung", "Analisis Data", "Keuangan"
akuntansi_indices = df_updated[df_updated['JURUSAN'] == 'AKUNTANSI'].index

for i, idx in enumerate(akuntansi_indices):
    if i < 7:  # 7 data pertama
        df_updated.at[idx, 'Unnamed: 6'] = 'Berhitung'
    elif i < 13: # 6 data berikutnya
        df_updated.at[idx, 'Unnamed: 6'] = 'Analisis Data'  
    else: # sisanya
        df_updated.at[idx, 'Unnamed: 6'] = 'Keuangan'

print("\nUpdated minat values:")
print(df_updated['Unnamed: 6'].value_counts())

print("\nMinat distribution by Jurusan:")
print(pd.crosstab(df_updated['Unnamed: 6'], df_updated['JURUSAN']))

# Simpan dataset
with pd.ExcelWriter('media/dataset.xlsx', engine='openpyxl') as writer:
    df_updated.to_excel(writer, sheet_name='Sheet1', index=False)

print("\nDataset updated with new minat choices!")
