import pandas as pd
from pathlib import Path

# Baca dataset
excel_path = Path('media/dataset.xlsx')
if excel_path.exists():
    xls = pd.ExcelFile(excel_path)
    print('Sheet names:', xls.sheet_names)
    
    # Baca sheet pertama
    df = pd.read_excel(excel_path, sheet_name=0)
    print('\nOriginal columns:', df.columns.tolist())
    print('\nFirst few rows:')
    print(df.head())
    
    # Cek kolom minat
    if 'Unnamed: 6' in df.columns:
        print('\nUnique values in Unnamed: 6 (minat column):')
        print(df['Unnamed: 6'].value_counts())
    elif 'minat' in df.columns:
        print('\nUnique values in minat column:')
        print(df['minat'].value_counts())
        
    # Cek kolom jurusan juga
    if 'Unnamed: 7' in df.columns:
        print('\nUnique values in Unnamed: 7 (jurusan column):')
        print(df['Unnamed: 7'].value_counts())
    elif 'JURUSAN' in df.columns:
        print('\nUnique values in JURUSAN column:')
        print(df['JURUSAN'].value_counts())
else:
    print('Dataset file not found!')
