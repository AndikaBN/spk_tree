
-- Jalankan ini di MySQL untuk membuat database & user (opsional)
CREATE DATABASE IF NOT EXISTS smk_rekomendasi CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
-- CREATE USER 'smkuser'@'%' IDENTIFIED BY 'strongpassword';
-- GRANT ALL PRIVILEGES ON smk_rekomendasi.* TO 'smkuser'@'%';
-- FLUSH PRIVILEGES;
